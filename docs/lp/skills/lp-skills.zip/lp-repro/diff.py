# -*- coding: utf-8 -*-
"""原画と再現を「同じ物差し」で測って、ズレを出す。再現ループの心臓部。

  python3 diff.py ref.png shot.png --bg clean.png --x 85,800 --y 100,720
      → 行を自動で対応付けて、1行ずつ dy と幅の差を出す

  python3 diff.py ref.png shot.png --bg clean.png --items items.json
      → 窓を名前つきで指定して、要素ごとに dx dy dw dh を出す

items.json の形（窓は「その要素しか入らない」範囲に切ること）
  [ {"name":"H1-1", "rect":[80,274,710,356]},
    {"name":"CTA",  "rect":[78,600,480,700]} ]

★ 大事なこと
  ・原画と再現を必ず同じ関数・同じ閾値で測る。目で見比べない
  ・--bg には「文字を消した背景」を渡す。背景がグラデーションでも文字だけ拾える
  ・数字が変な時は必ず拡大して目で確認する。写真の柱を文字と誤検出したことがある
"""
import argparse, json
from PIL import Image


def lum(p):
    return 0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]


def load(path, size):
    im = Image.open(path).convert('RGB')
    return im if im.size == size else im.resize(size, Image.LANCZOS)


class Probe:
    def __init__(self, im, bg=None, th=40, light=False):
        self.px = im.load(); self.W, self.H = im.size
        self.bg = bg.load() if bg else None
        self.th = th; self.light = light

    def hit(self, x, y):
        if self.bg:
            a, b = self.px[x, y], self.bg[x, y]
            return abs(a[0]-b[0]) + abs(a[1]-b[1]) + abs(a[2]-b[2]) > self.th
        L = lum(self.px[x, y])
        return L > self.th if self.light else L < self.th

    def rows(self, x0, x1, y0, y1, minh=4, step=2):
        out, inr, s = [], False, 0
        for y in range(y0, y1):
            h = any(self.hit(x, y) for x in range(x0, x1, step))
            if h and not inr: s, inr = y, True
            if not h and inr: out.append((s, y-1)); inr = False
        if inr: out.append((s, y1-1))
        return [(a, b) for a, b in out if b-a+1 >= minh]

    def span(self, y0, y1, x0, x1):
        xs = [x for y in range(y0, y1) for x in range(x0, x1) if self.hit(x, y)]
        return (min(xs), max(xs)) if xs else None

    def box(self, x0, y0, x1, y1):
        xs, ys = [], []
        for y in range(y0, y1):
            for x in range(x0, x1):
                if self.hit(x, y): xs.append(x); ys.append(y)
        return (min(xs), min(ys), max(xs), max(ys)) if xs else None


def score(a, b, step=3):
    pa, pb = a.load(), b.load()
    W, H = a.size
    d = n = 0
    for y in range(0, H, step):
        for x in range(0, W, step):
            p, q = pa[x, y], pb[x, y]
            d += abs(p[0]-q[0]) + abs(p[1]-q[1]) + abs(p[2]-q[2]); n += 3
    return d / n


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('ref'); ap.add_argument('shot')
    ap.add_argument('--bg'); ap.add_argument('--items')
    ap.add_argument('--x'); ap.add_argument('--y')
    ap.add_argument('--th', type=float, default=40)
    ap.add_argument('--light', action='store_true')
    ap.add_argument('--minh', type=int, default=4)
    a = ap.parse_args()

    A = Image.open(a.ref).convert('RGB')
    size = A.size
    B = load(a.shot, size)
    G = load(a.bg, size) if a.bg else None
    pa, pb = Probe(A, G, a.th, a.light), Probe(B, G, a.th, a.light)

    if a.items:
        items = json.load(open(a.items))
        print(f"{'要素':<14}{'原画 x,y (w x h)':>26}{'再現 x,y (w x h)':>26}   ズレ")
        worst = []
        for it in items:
            x0, y0, x1, y1 = it['rect']
            ba, bb = pa.box(x0, y0, x1, y1), pb.box(x0, y0, x1, y1)
            if not ba or not bb:
                print(f"{it['name']:<14}{'—' if not ba else 'ok':>26}{'検出なし' if not bb else 'ok':>26}")
                continue
            dx, dy = bb[0]-ba[0], bb[1]-ba[1]
            dw, dh = (bb[2]-bb[0])-(ba[2]-ba[0]), (bb[3]-bb[1])-(ba[3]-ba[1])
            fa = f"{ba[0]},{ba[1]} ({ba[2]-ba[0]+1}x{ba[3]-ba[1]+1})"
            fb = f"{bb[0]},{bb[1]} ({bb[2]-bb[0]+1}x{bb[3]-bb[1]+1})"
            bad = max(abs(dx), abs(dy), abs(dw), abs(dh))
            print(f"{it['name']:<14}{fa:>26}{fb:>26}   dx{dx:+4d} dy{dy:+4d} dw{dw:+4d} dh{dh:+4d}"
                  + ('  ←' if bad > 4 else ''))
            worst.append((bad, it['name']))
        worst.sort(reverse=True)
        if worst:
            print('\nズレの大きい順:', ', '.join(f'{n}({v})' for v, n in worst[:6]))
    else:
        x0, x1 = (int(v) for v in a.x.split(',')) if a.x else (0, size[0])
        y0, y1 = (int(v) for v in a.y.split(',')) if a.y else (0, size[1])
        ra, rb = pa.rows(x0, x1, y0, y1, a.minh), pb.rows(x0, x1, y0, y1, a.minh)
        print(f'  原画 {len(ra)}行 / 再現 {len(rb)}行'
              + ('' if len(ra) == len(rb) else '  ← 行数が違う。窓か閾値を見直す'))
        print(f"{'#':<4}{'原画 y (高さ)':>18}{'再現 y (高さ)':>18}{'dy':>6}{'原画 x':>16}{'再現 x':>16}{'dw':>6}")
        for i in range(min(len(ra), len(rb))):
            (s1, e1), (s2, e2) = ra[i], rb[i]
            sa, sb = pa.span(s1, e1+1, x0, x1), pb.span(s2, e2+1, x0, x1)
            dw = (sb[1]-sb[0]) - (sa[1]-sa[0]) if sa and sb else 0
            print(f'{i+1:<4}{f"{s1}-{e1} ({e1-s1+1})":>18}{f"{s2}-{e2} ({e2-s2+1})":>18}'
                  f'{s2-s1:+6d}{f"{sa[0]}-{sa[1]}" if sa else "-":>16}'
                  f'{f"{sb[0]}-{sb[1]}" if sb else "-":>16}{dw:+6d}')

    print(f'\n全面の平均チャンネル差: {score(A, B):.2f} / 255'
          '   （文字のラスタライズ差で 5〜8 は残る。背景だけなら ±3 を目安に）')


if __name__ == '__main__':
    main()
