# -*- coding: utf-8 -*-
"""再現したHTMLを headless Chrome で撮る。

  python3 shot.py http://127.0.0.1:8093/x.html out.png --size 1536x1024
  python3 shot.py file.html out.png --size 1440x780

★ 罠
  ・スマホ幅（375px）の headless 描画は当てにならない。溢れて見えるのに実ブラウザでは正常、
    という誤判定を何度も踏んだ。スマホの検証はブラウザで見ること
  ・100svh のセクションがあると、縦に長い窓で撮ったときヒーローが窓いっぱいに伸びて
    下のセクションが写らない。セクション単位で撮るページを別に作る
  ・Webフォントの読み込み待ちに --virtual-time-budget を必ず入れる
"""
import argparse, subprocess, sys, os

CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('url'); ap.add_argument('out')
    ap.add_argument('--size', default='1536x1024')
    ap.add_argument('--wait', type=int, default=9000)
    a = ap.parse_args()
    w, h = a.size.lower().split('x')
    url = a.url
    if not url.startswith(('http://', 'https://', 'file://')):
        url = 'file://' + os.path.abspath(url)
    if not os.path.exists(CHROME):
        sys.exit(f'Chrome が見つからない: {CHROME}')
    subprocess.run([CHROME, '--headless', '--disable-gpu', '--hide-scrollbars',
                    '--force-device-scale-factor=1', f'--window-size={w},{h}',
                    f'--screenshot={os.path.abspath(a.out)}',
                    f'--virtual-time-budget={a.wait}', url],
                   stderr=subprocess.DEVNULL)
    if os.path.exists(a.out):
        from PIL import Image
        print(f'{a.out}  {Image.open(a.out).size}')
    else:
        sys.exit('撮影に失敗した')


if __name__ == '__main__':
    main()
