# -*- coding: utf-8 -*-
"""原画からアイコン・図版を抜き出す。自分で描き直すより速くて正確。

  # 円の中の線画 → 透過マスク（色はCSSの background で変えられる）
  python3 extract.py ref.png circle --cx 582 --cy 291 --r 47 -o img/ic-chat.png

  # 濃い地に白抜きの線画
  python3 extract.py ref.png circle --cx 892 --cy 291 --r 45 --invert -o img/ic-calc.png

  # 円の左上に番号バッジが重なっている時は、その円を除外する
  python3 extract.py ref.png circle --cx 139 --cy 834 --r 46 --exclude 128,798,27 -o img/ic-plan.png

  # 矩形の中の線画
  python3 extract.py ref.png box --rect 105,1236,138,1276 -o img/ic-web.png

  # 写真・イラストを背景透過のカラーPNGで
  python3 extract.py ref.png photo --rect 362,1240,549,1370 -o img/ws.png

  # そのまま切り出し
  python3 extract.py ref.png crop --rect 872,105,1536,1024 -o img/hero.jpg

使い方（CSS側）
  透過マスクは色を変えられる形で当てる:
    .ico{ width:56px; aspect-ratio:54/48; background:#12315b;
          -webkit-mask:url(ic-chat.png) center/contain no-repeat;
                  mask:url(ic-chat.png) center/contain no-repeat }
  ★ 出力の縦横比を aspect-ratio にそのまま書くこと（実行時に表示される）

★ 覚えておくこと
  ・線画アイコンは自分でSVGを描くと形が出ない（握手・ロケットで2回失敗した）
  ・白抜きは明暗のしきい値の向きが逆。--invert を忘れると反転して出る
  ・--invert の時は floor を上げる（地の紺が薄く残って四角い影になる）
"""
import argparse
from PIL import Image


def lum(p):
    return 0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('image')
    ap.add_argument('mode', choices=['circle', 'box', 'photo', 'crop'])
    ap.add_argument('-o', '--out', required=True)
    ap.add_argument('--cx', type=int); ap.add_argument('--cy', type=int); ap.add_argument('--r', type=int)
    ap.add_argument('--inner', type=int, default=9, help='円の枠を除くための内側マージン')
    ap.add_argument('--exclude', help='除外する円 cx,cy,r（番号バッジなど）')
    ap.add_argument('--rect')
    ap.add_argument('--invert', action='store_true', help='濃い地に白抜き')
    ap.add_argument('--th', type=float, help='要素と地を分けるしきい値')
    ap.add_argument('--floor', type=float, help='ここまでは完全に透過（--invert 時は 95 くらい）')
    ap.add_argument('--ink', type=float, help='ここで完全に不透明')
    a = ap.parse_args()

    im = Image.open(a.image).convert('RGB')
    px = im.load()

    if a.mode == 'crop':
        x0, y0, x1, y1 = [int(v) for v in a.rect.split(',')]
        c = im.crop((x0, y0, x1, y1))
        c.save(a.out, quality=94, subsampling=0) if a.out.lower().endswith(('.jpg', '.jpeg')) else c.save(a.out)
        print(f'{a.out}  {c.size[0]}x{c.size[1]}')
        return

    th = a.th if a.th is not None else (150 if a.invert else 190)
    floor = a.floor if a.floor is not None else (95.0 if a.invert else 248.0)
    ink = a.ink if a.ink is not None else (235.0 if a.invert else 30.0)

    exc = None
    if a.exclude:
        ex, ey, er = [int(v) for v in a.exclude.split(',')]
        exc = (ex, ey, er * er)

    if a.mode == 'circle':
        rr = a.r - a.inner
        def ok(x, y):
            if (x-a.cx)**2 + (y-a.cy)**2 > rr*rr: return False
            if exc and (x-exc[0])**2 + (y-exc[1])**2 <= exc[2]: return False
            return True
        X0, Y0, X1, Y1 = a.cx-rr, a.cy-rr, a.cx+rr+1, a.cy+rr+1
    else:
        X0, Y0, X1, Y1 = [int(v) for v in a.rect.split(',')]
        ok = lambda x, y: not (exc and (x-exc[0])**2 + (y-exc[1])**2 <= exc[2])

    if a.mode == 'photo':
        # 明るい地を抜いた、色つきの透過PNG
        out = Image.new('RGBA', (X1-X0, Y1-Y0)); po = out.load()
        hi, lo = 243.0, 225.0
        for y in range(Y0, Y1):
            for x in range(X0, X1):
                r, g, b = px[x, y]; L = lum((r, g, b))
                al = 1.0 if L < lo else max(0.0, (hi - L) / (hi - lo))
                po[x-X0, y-Y0] = (r, g, b, int(max(0.0, min(1.0, al)) * 255))
        out.save(a.out)
        print(f'{a.out}  {out.size[0]}x{out.size[1]}   aspect-ratio:{out.size[0]}/{out.size[1]}')
        return

    # 線画 → 透過マスク（自動でトリム）
    xs, ys = [], []
    for y in range(Y0, Y1):
        for x in range(X0, X1):
            if not ok(x, y): continue
            L = lum(px[x, y])
            if (L > th) if a.invert else (L < th):
                xs.append(x); ys.append(y)
    if not xs:
        print('検出なし。しきい値（--th）か範囲を見直す'); return
    bx0, by0 = max(0, min(xs)-2), max(0, min(ys)-2)
    bx1, by1 = min(im.size[0], max(xs)+3), min(im.size[1], max(ys)+3)

    out = Image.new('LA', (bx1-bx0, by1-by0)); po = out.load()
    for y in range(by0, by1):
        for x in range(bx0, bx1):
            if not ok(x, y):
                po[x-bx0, y-by0] = (0, 0); continue
            L = lum(px[x, y])
            al = (L - floor) / (ink - floor) if a.invert else (floor - L) / (floor - ink)
            po[x-bx0, y-by0] = (0, int(max(0.0, min(1.0, al)) * 255))
    out.save(a.out)
    w, h = out.size
    print(f'{a.out}  {w}x{h}   aspect-ratio:{w}/{h}')
    print(f'  CSS: background:<色>; -webkit-mask:url({a.out.split("/")[-1]}) center/contain no-repeat; mask:同上')


if __name__ == '__main__':
    main()
