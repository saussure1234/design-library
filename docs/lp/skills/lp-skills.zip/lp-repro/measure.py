# -*- coding: utf-8 -*-
"""デザイン画像を実測する。目分量をコードに書かないための道具。

  python3 measure.py ref.png rows   --x 85,800 --y 100,720     行の位置（＝要素の縦位置と行送り）
  python3 measure.py ref.png cols   --y 283,364 --x 85,800     字の切れ目（＝字送り＝フォントサイズ）
  python3 measure.py ref.png box    --rect 85,255,540,300      外接矩形と色
  python3 measure.py ref.png color  --rect 85,255,540,300      最頻色・最暗色・平均色
  python3 measure.py ref.png vline  --x 300,400 --y 200,500    縦罫の位置
  python3 measure.py ref.png hline  --y 180,220 --x 60,960     横罫の位置
  python3 measure.py ref.png circle --y 291 --x 500,990        その行にある円の左右端

共通オプション
  --bg clean.png   背景画像。指定すると「原画 − 背景」の差分で測る。
                   背景がグラデーションの時はこれを使わないと閾値では拾えない。
  --th 200         明暗の閾値（--bg 指定時は差分の閾値）
  --light          明るい方を対象にする（濃い地に白抜きの文字・アイコン）
"""
import sys, argparse
from collections import Counter
from PIL import Image


def lum(p):
    return 0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]


class M:
    def __init__(self, path, bg=None, th=200, light=False):
        self.im = Image.open(path).convert('RGB')
        self.px = self.im.load()
        self.W, self.H = self.im.size
        self.th = th
        self.light = light
        self.bg = None
        if bg:
            b = Image.open(bg).convert('RGB')
            if b.size != self.im.size:
                b = b.resize(self.im.size, Image.LANCZOS)
            self.bg = b.load()

    def hit(self, x, y):
        """その画素が『要素』か。背景画像があれば差分で、無ければ明暗で判定"""
        if self.bg:
            a, b = self.px[x, y], self.bg[x, y]
            return abs(a[0]-b[0]) + abs(a[1]-b[1]) + abs(a[2]-b[2]) > self.th
        L = lum(self.px[x, y])
        return L > self.th if self.light else L < self.th

    # ---- 行 ----
    def rows(self, x0, x1, y0, y1, minh=3, step=1):
        out, inr, s = [], False, 0
        for y in range(y0, y1):
            h = any(self.hit(x, y) for x in range(x0, x1, step))
            if h and not inr:
                s, inr = y, True
            if not h and inr:
                out.append((s, y - 1)); inr = False
        if inr:
            out.append((s, y1 - 1))
        return [(a, b) for a, b in out if b - a + 1 >= minh]

    # ---- 列（字の切れ目）----
    def cols(self, y0, y1, x0, x1, minw=1):
        out, inr, s = [], False, 0
        for x in range(x0, x1):
            h = any(self.hit(x, y) for y in range(y0, y1))
            if h and not inr:
                s, inr = x, True
            if not h and inr:
                out.append((s, x - 1)); inr = False
        if inr:
            out.append((s, x1 - 1))
        return [(a, b) for a, b in out if b - a + 1 >= minw]

    # ---- 外接矩形 ----
    def box(self, x0, y0, x1, y1):
        xs, ys = [], []
        for y in range(y0, y1):
            for x in range(x0, x1):
                if self.hit(x, y):
                    xs.append(x); ys.append(y)
        if not xs:
            return None
        return (min(xs), min(ys), max(xs), max(ys))

    # ---- 色 ----
    def colors(self, x0, y0, x1, y1):
        cs = [self.px[x, y] for y in range(y0, y1) for x in range(x0, x1)]
        n = len(cs)
        avg = tuple(sum(c[i] for c in cs) // n for i in range(3))
        srt = sorted(cs, key=lum)
        k = max(1, n // 20)
        dark = tuple(sum(c[i] for c in srt[:k]) // k for i in range(3))
        mode_all = Counter(cs).most_common(1)[0]
        ink = [c for c in cs if (lum(c) > self.th if self.light else lum(c) < self.th)]
        mode_ink = Counter(ink).most_common(1)[0] if ink else None
        f = lambda c: '#%02x%02x%02x' % c
        return {
            '平均': f(avg),
            '最暗5%': f(dark),
            '最頻': f(mode_all[0]) + f'（{mode_all[1]}px）',
            '要素の最頻': (f(mode_ink[0]) + f'（{mode_ink[1]}px）') if mode_ink else '—',
        }

    # ---- 罫 ----
    def vlines(self, x0, x1, y0, y1, d=3.0):
        out, prev = [], None
        for x in range(x0, x1):
            v = sum(lum(self.px[x, y]) for y in range(y0, y1)) / (y1 - y0)
            if prev is not None and abs(v - prev) > d:
                out.append((x, round(prev, 1), round(v, 1)))
            prev = v
        return out

    def hlines(self, y0, y1, x0, x1, d=3.0):
        out, prev = [], None
        for y in range(y0, y1):
            v = sum(lum(self.px[x, y]) for x in range(x0, x1)) / (x1 - x0)
            if prev is not None and abs(v - prev) > d:
                out.append((y, round(prev, 1), round(v, 1)))
            prev = v
        return out

    # ---- その行を横切る要素をすべて出す（円の枠・罫・字が混ざるので人が読む）----
    def scan_row(self, yc, x0, x1):
        out, inr, s = [], False, 0
        for x in range(x0, x1):
            h = self.hit(x, yc)
            if h and not inr: s, inr = x, True
            if not h and inr: out.append((s, x-1)); inr = False
        if inr: out.append((s, x1-1))
        return out


def parse_pair(v):
    if ',' not in v:          # 単一の値なら「その1行/1列」を指す
        n = int(v); return n, n + 1
    a, b = v.split(',')
    return int(a), int(b)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('image')
    ap.add_argument('mode', choices=['rows', 'cols', 'box', 'color', 'vline', 'hline', 'circle'])
    ap.add_argument('--x'); ap.add_argument('--y'); ap.add_argument('--rect')
    ap.add_argument('--bg'); ap.add_argument('--th', type=float, default=200)
    ap.add_argument('--light', action='store_true')
    ap.add_argument('--minh', type=int, default=3)
    ap.add_argument('--d', type=float, default=3.0)
    a = ap.parse_args()

    m = M(a.image, a.bg, a.th, a.light)
    W, H = m.W, m.H
    print(f'{a.image}  {W}x{H}' + ('  ／ 背景差分で測定' if a.bg else ''))

    if a.rect:
        x0, y0, x1, y1 = [int(v) for v in a.rect.split(',')]
    else:
        x0, x1 = parse_pair(a.x) if a.x else (0, W)
        y0, y1 = parse_pair(a.y) if a.y else (0, H)

    if a.mode == 'rows':
        r = m.rows(x0, x1, y0, y1, a.minh)
        print(f'  行 {len(r)}本')
        prev = None
        for s, e in r:
            gap = f'  行送り{s-prev:+d}' if prev is not None else ''
            print(f'   y {s:5d}-{e:5d}  高さ{e-s+1:4d}{gap}')
            prev = s
    elif a.mode == 'cols':
        c = m.cols(y0, y1, x0, x1)
        print(f'  塊 {len(c)}個')
        print('  ', c)
        st = [v[0] for v in c]
        if len(st) > 2:
            adv = [st[i+1]-st[i] for i in range(len(st)-1)]
            print(f'  字送り {adv}')
            print(f'  ★ 平均 {sum(adv)/len(adv):.1f}px  ＝ 和文ならフォントサイズの目安')
            print(f'    字面 {c[-1][1]-c[0][0]+1}px（左端{c[0][0]} 〜 右端{c[-1][1]}）')
    elif a.mode == 'box':
        b = m.box(x0, y0, x1, y1)
        if b:
            print(f'  x {b[0]}-{b[2]} (幅{b[2]-b[0]+1})   y {b[1]}-{b[3]} (高さ{b[3]-b[1]+1})')
            for k, v in m.colors(b[0], b[1], b[2]+1, b[3]+1).items():
                print(f'   {k}: {v}')
        else:
            print('  検出なし')
    elif a.mode == 'color':
        for k, v in m.colors(x0, y0, x1, y1).items():
            print(f'  {k}: {v}')
    elif a.mode == 'vline':
        for x, p, v in m.vlines(x0, x1, y0, y1, a.d):
            print(f'  x={x}  {p} -> {v}')
    elif a.mode == 'hline':
        for y, p, v in m.hlines(y0, y1, x0, x1, a.d):
            print(f'  y={y}  {p} -> {v}')
    elif a.mode == 'circle':
        yc = y0
        runs = m.scan_row(yc, x0, x1)
        print(f'  y={yc} を横切る要素（幅つき）:')
        for s0, s1 in runs:
            kind = '細い（枠・罫の候補）' if s1-s0 <= 5 else '太い（塗り・字）'
            print(f'   x {s0:5d}-{s1:5d}  幅{s1-s0+1:4d}  {kind}')
        print('  ★ 円の中心は「細い要素の対」から出す。字や罫が混ざるので、')
        print('    必ず該当箇所を拡大して目で確かめること')


if __name__ == '__main__':
    main()
