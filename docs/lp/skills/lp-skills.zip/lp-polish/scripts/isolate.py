# -*- coding: utf-8 -*-
"""1セクションだけを撮るためのページを作る。

LP全体を撮ると 100svh の節や下の節が邪魔で、直したい箇所が写らない。
このスクリプトは「その節だけを表示し、登場アニメは終わった状態にし、
無限アニメは指定した時刻で止めた」ページを吐く。

  python3 isolate.py index.html .why                    → _shot/iso_why.html
  python3 isolate.py index.html .book --t 2600          → 無限アニメを2600msで止める
  python3 isolate.py index.html .hero --hide-copy       → 文字を消す（背景のコントラスト測定用）
  python3 isolate.py index.html .strengths --keep .d4   → その節のうち .d4 を含むカードだけ残す

そのあと撮る：
  python3 ~/.claude/skills/lp-repro/shot.py "file://$PWD/_shot/iso_why.html" out.png --size 1440x900

なぜ毎回これが要るか
  - 登場アニメを t=0 で止めると opacity:0 のまま何も写らない
    → 有限のものは finish()、無限のものだけ pause() する
  - _shot/ から見ると img/... が引けない → <base href="../"> を差す
  - mask-image のアイコンは file:// では出ない。実害はないのでそこで悩まない
"""
import argparse, io, os, re, sys


TPL = """
<style>
body > *%(notsel)s{display:none !important}
%(extra)s
</style>
<script>
(function () {
  function go() {
    document.querySelectorAll('[data-rv]').forEach(function (e) { e.classList.add('is-in'); });
    %(keep)s
    document.getAnimations().forEach(function (a) {
      try {
        var it = a.effect.getTiming().iterations;
        if (it === Infinity) {                       /* 無限アニメ：指定時刻で止める */
          a.pause();
          a.currentTime = %(t)d %% (a.effect.getTiming().duration || 1000);
        } else {                                     /* 登場アニメ：終わらせる */
          a.finish();
        }
      } catch (e) {}
    });
  }
  if (document.readyState === 'complete') go(); else addEventListener('load', go);
  setTimeout(go, 150); setTimeout(go, 500); setTimeout(go, 900);
})();
</script>
"""

KEEP = """
    var t = document.querySelector('%(keep)s');
    if (t) {
      var card = t.closest('.s-card') || t.closest('.s-row') || t.parentElement;
      document.querySelectorAll('.s-card, .s-row').forEach(function (r) {
        if (r !== card && !r.contains(t)) r.style.display = 'none';
      });
    }
"""


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('html')
    ap.add_argument('selector', help='残す節のセレクタ（例 .why / #price / .strengths）')
    ap.add_argument('--t', type=int, default=0, help='無限アニメを止める時刻(ms)')
    ap.add_argument('--hide-copy', action='store_true', help='.copy を透明にする（背景測定用）')
    ap.add_argument('--keep', default=None, help='節の中で、このセレクタを含むカードだけ残す')
    ap.add_argument('--head', action='store_true', help='ヘッダーも残す')
    ap.add_argument('-o', '--out', default=None)
    a = ap.parse_args()

    src = io.open(a.html, encoding='utf-8').read()
    if '<base' not in src:
        src = src.replace('<head>', '<head>\n<base href="../">', 1)

    keeps = [a.selector] + (['#head'] if a.head else [])
    notsel = ''.join(':not(%s)' % s for s in keeps)

    extra = []
    if not a.head:
        extra.append('#head{display:none !important}')
    if a.hide_copy:
        extra.append('.copy{visibility:hidden !important}')

    inject = TPL % {
        'notsel': notsel,
        'extra': '\n'.join(extra),
        't': a.t,
        'keep': (KEEP % {'keep': a.keep}) if a.keep else '',
    }

    outdir = os.path.join(os.path.dirname(os.path.abspath(a.html)), '_shot')
    os.makedirs(outdir, exist_ok=True)
    name = a.out or ('iso_' + re.sub(r'[^a-zA-Z0-9_-]', '', a.selector) + '.html')
    out = os.path.join(outdir, name)

    body = src.replace('</body>', inject + '</body>') if '</body>' in src else src + inject
    io.open(out, 'w', encoding='utf-8').write(body)
    print(out)


if __name__ == '__main__':
    main()
