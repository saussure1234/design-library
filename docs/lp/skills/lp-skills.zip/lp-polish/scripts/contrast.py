# -*- coding: utf-8 -*-
"""文字を消した背景を描き出して、行ごとにコントラストを測る。

なぜ「文字を消した背景」が必要か
  文字入りの画像で行の上をサンプルすると、前の行のグリフを拾って
  「コントラスト1.0」のような嘘の値が出る。一度これで誤診した。
  isolate.py --hide-copy で文字を消した版を作ってから測る。

使い方
  1) 背景だけの版を撮る
     python3 ~/.claude/skills/lp-polish/scripts/isolate.py index.html .hero --hide-copy --t 2600
     python3 ~/.claude/skills/lp-repro/shot.py "file://$PWD/_shot/iso_hero.html" bg.png --size 1440x760

  2) 行の位置と文字色をブラウザから取る（下の JS を貼る）

  3) 測る
     python3 contrast.py bg.png rows.json
     python3 contrast.py bg.png rows.json --white   # 白文字（最悪ケースが逆になる）

rows.json の形
  [{"t":"見出し1行目","x0":126,"x1":588,"y0":190,"y1":250,"fg":[22,22,26],"fs":46}, ...]

行を取る JS（ブラウザに貼る）
  const rng=document.createRange(); const out=[];
  const w=document.createTreeWalker(document.querySelector('.copy'), NodeFilter.SHOW_TEXT);
  let n; while((n=w.nextNode())){
    if(!n.nodeValue.trim()) continue;
    if(n.parentElement.closest('form')) continue;
    rng.selectNodeContents(n);
    [...rng.getClientRects()].forEach(r=>{ if(r.width<4) return;
      const cs=getComputedStyle(n.parentElement);
      out.push({t:n.nodeValue.trim().slice(0,14),
        x0:Math.round(r.left), x1:Math.round(r.right),
        y0:Math.round(r.top),  y1:Math.round(r.bottom),
        fg:cs.color.match(/\\d+/g).slice(0,3).map(Number),
        fs:parseFloat(cs.fontSize)});
    });
  }
  JSON.stringify(out)

しきい値
  本文 4.5:1 ／ 24px以上、または18.66px以上の太字なら 3:1
  それ未満の太字に 3:1 の緩和は使えない
"""
import argparse, io, json, sys
from PIL import Image


def rl(c):
    def f(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return .2126 * f(c[0]) + .7152 * f(c[1]) + .0722 * f(c[2])


def cr(a, b):
    L1, L2 = rl(a), rl(b)
    if L1 < L2:
        L1, L2 = L2, L1
    return (L1 + .05) / (L2 + .05)


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('image')
    ap.add_argument('rows', help='行の JSON（ファイル、または - で標準入力）')
    ap.add_argument('--white', action='store_true',
                    help='白系の文字。最悪ケースが「一番明るい背景」になる')
    ap.add_argument('--bold-large', type=float, default=18.66,
                    help='太字で3:1が許される下限px')
    a = ap.parse_args()

    rows = json.load(sys.stdin if a.rows == '-' else io.open(a.rows, encoding='utf-8'))
    im = Image.open(a.image).convert('RGB')
    px = im.load()
    W, H = im.size

    print('%s  %dx%d   %s' % (a.image, W, H, '白文字モード' if a.white else '濃色文字モード'))
    print('%-22s%6s%10s%8s  %s' % ('行', 'font', '最悪背景', 'コントラスト', '判定'))
    ng = 0
    worst_all = 99.0
    for r in rows:
        x0, x1 = max(0, r['x0']), min(W - 1, r['x1'])
        y0, y1 = max(0, r['y0']), min(H - 1, r['y1'])
        if x1 <= x0 or y1 <= y0:
            print('%-22s  範囲が画像の外' % r.get('t', '?'))
            continue
        cells = [px[x, y] for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)]
        # 白文字なら一番明るい背景、濃色文字なら一番暗い背景が最悪
        worst = max(cells, key=lambda c: sum(c)) if a.white else min(cells, key=lambda c: sum(c))
        fs = float(r.get('fs', 16))
        need = 3.0 if fs >= 24 else 4.5          # 太字の緩和は呼び出し側で fs を上げて表現する
        c = cr(r['fg'], worst)
        ok = c >= need
        if not ok:
            ng += 1
        worst_all = min(worst_all, c / need)
        print('%-22s%6.1f%10d%8.1f  %s（要%.1f）'
              % (r.get('t', '?')[:20], fs, sum(worst) // 3, c, 'OK' if ok else 'NG', need))

    print('\nNG %d 件' % ng)
    if ng:
        print('※ 白文字のときは --white を忘れていないか確認する（最悪ケースが逆になる）')
    return 1 if ng else 0


if __name__ == '__main__':
    sys.exit(main())
