/* LPの回帰チェックを1発で出す。ブラウザのコンソール（または javascript_tool）に貼る。
 *
 *   __audit()                     … 今の幅で測る
 *   __audit({scroll:'.cmp-scroll,.pq-scroll'})
 *                                 … 意図的な横スクロール領域を除外する
 *
 * 出るもの
 *   ov        … 横に溢れている要素（意図的なスクロール領域の中は除外）
 *   truncated … overflow が visible でないのに中身が入っていない要素（文字切れ）
 *   tiny      … 本文が12px未満の要素（図中の字を見落としやすい）
 *   smallTap  … 高さ40px未満のリンク/ボタン/入力（行内リンクは仕様なので目視で切る）
 *   anim      … 走っている無限アニメの本数
 *   hidden    … document.hidden（true だとアニメが止まるので測定不能）
 *
 * 注意
 *   - リサイズ直後は待ってから呼ぶ。getBoundingClientRect が古い値を返す
 *   - data-rv のスクロール表示は先に is-in を付けて全部出してから測る
 */
window.__audit = function (opt) {
  opt = opt || {};
  document.querySelectorAll('[data-rv]').forEach(function (e) { e.classList.add('is-in'); });

  var W = document.documentElement.clientWidth;
  var scrolls = opt.scroll ? [].slice.call(document.querySelectorAll(opt.scroll)) : [];
  var inScroll = function (e) { return scrolls.some(function (s) { return s.contains(e); }); };
  var name = function (e) {
    var c = (typeof e.className === 'string' ? e.className.split(' ')[0] : '');
    return e.tagName + (c ? '.' + c : '');
  };

  var all = [].slice.call(document.querySelectorAll('body *'));

  var ov = all.filter(function (e) {
    var r = e.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    if (getComputedStyle(e).position === 'fixed') return false;
    if (e.closest('svg')) return false;
    if (inScroll(e)) return false;
    return r.right > W + 1 || r.left < -1;
  }).map(name);

  var truncated = all.filter(function (e) {
    if (e.children.length) return false;
    if (!e.textContent.trim()) return false;
    if (getComputedStyle(e).overflow === 'visible') return false;
    return e.scrollWidth > e.clientWidth + 2;
  }).map(function (e) { return name(e) + ' | ' + e.textContent.trim().slice(0, 20); });

  var tiny = all.filter(function (e) {
    if (e.children.length) return false;
    if (e.textContent.trim().length < 5) return false;
    return parseFloat(getComputedStyle(e).fontSize) < 12;
  }).map(function (e) {
    return Math.round(parseFloat(getComputedStyle(e).fontSize) * 10) / 10 + 'px ' +
           name(e) + ' | ' + e.textContent.trim().slice(0, 18);
  });

  var smallTap = [].slice.call(document.querySelectorAll('a,button,input,summary,label'))
    .filter(function (e) {
      var r = e.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && r.height < 40;
    }).map(function (e) {
      return name(e) + ' ' + Math.round(e.getBoundingClientRect().height) + 'px';
    });

  var anim = 0;
  try {
    anim = document.getAnimations().filter(function (a) {
      return a.playState === 'running' && a.effect.getTiming().iterations === Infinity;
    }).length;
  } catch (e) {}

  // Set に length がないので slice.call は空配列を返す。Array.from を使う
  var uniq = function (a) { return Array.from(new Set(a)); };

  return {
    vw: innerWidth,
    docW: document.documentElement.scrollWidth,
    pageOverflow: document.documentElement.scrollWidth > W + 1,
    ov: uniq(ov).slice(0, 8),
    ovCount: ov.length,
    truncated: uniq(truncated).slice(0, 8),
    tiny: uniq(tiny).slice(0, 8),
    smallTap: uniq(smallTap).slice(0, 8),
    anim: anim,
    hidden: document.hidden
  };
};

/* 保護色を敷いた要素の文字コントラストを一括で見る。
 * 18.66px未満の太字は 3:1 の緩和が使えないので、しきい値を自動で振り分ける。 */
window.__ctaContrast = function () {
  var rl = function (c) {
    var f = function (v) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
  };
  var px = function (s) { var m = s.match(/\d+/g); return m ? m.slice(0, 3).map(Number) : null; };
  var cr = function (a, b) { var x = rl(a), y = rl(b); if (x < y) { var t = x; x = y; y = t; } return (x + 0.05) / (y + 0.05); };

  var out = [], seen = {};
  document.querySelectorAll('a,button,span,input[type=submit]').forEach(function (e) {
    var cs = getComputedStyle(e), bg = px(cs.backgroundColor), fg = px(cs.color);
    if (!bg || !fg) return;
    if (cs.backgroundColor.indexOf('rgba(0, 0, 0, 0)') === 0) return;
    var fs = parseFloat(cs.fontSize), fw = parseInt(cs.fontWeight) || 400;
    var need = (fs >= 24 || (fs >= 18.66 && fw >= 700)) ? 3 : 4.5;
    var c = cr(fg, bg);
    var k = (typeof e.className === 'string' ? e.className.split(' ')[0] : e.tagName) + cs.backgroundColor + fs;
    if (seen[k]) return; seen[k] = 1;
    out.push({
      el: (typeof e.className === 'string' ? e.className.split(' ')[0] : e.tagName),
      bg: cs.backgroundColor, fs: Math.round(fs * 10) / 10,
      cr: Math.round(c * 100) / 100, need: need, ok: c >= need
    });
  });
  return { count: out.length, ng: out.filter(function (o) { return !o.ok; }), all: out };
};
