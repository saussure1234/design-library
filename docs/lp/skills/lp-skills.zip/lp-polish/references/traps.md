# 踏んだ罠

すべて実際に起きたもの。**CSSを書く前に目を通すほうが、あとで探すより安い。**

---

## CSS

**要素セレクタが class を食う。** `.fstep p{margin-top:26px}` は
`.fstep__no` や `.fstep__when` にも当たる。本文用のクラスを作って
`.fstep .fstep__desc` を狙う。

**`<i>` を装飾に使っている場所で `親 i{}` と書くと壊れる。**
`.fcaps i{position:absolute}` が「準備」の屋根の脚（`.fcap--2 > i`）まで拾って横線が消えた。
**自分の要素だけを名指しする。**

**同じ詳細度は後ろが勝つ。** `.pq__row--h{display:none}` を `.pq__row{display:block}` の
**前**に書くと効かない。上書きは必ず後ろに置く。

**`--rev` のような反転クラスの中で `left/right` を戻し忘れる。**
反転行だけ要素が逆側に飛ぶ。

**`.d4__cloud span` のような子孫セレクタが、後から足した `.d4__x` に勝つ。**
`(0,2,0) > (0,1,0)`。`.d4__cloud .d4__x` まで上げる。

**`min-height` が効かない。** grid に空の行が残っていると、そちらが高さを決めている。
`grid-template-rows` を確認する（`--band-h` の空行が196px残っていた）。

**`height:%` は絶対配置の親だと親の高さ基準。** 効かないときは `vw` にする。

**`display:contents` の親には `.parent > .child` がマッチしない。**
position は子自身に書く。

**`max-width` が `object-fit:contain` の高さを縮める。**
`height` を上げても効かないのはこれ。上限を緩める。

**`:hover` は `@media (hover:hover)` で包む。** 包まないとタップ後に残る。

---

## アニメーション

**🚨 `stroke-dashoffset` の keyframe に `calc(var(--x))` を書くと補間されない。**
CSSが離散補間に落ちるので、値が50%で飛ぶだけになる。線ごとに実数で書く。
→ `background-and-diagrams.md`

**1本の線で dasharray を動かすと形ごと消える。** 静止版と流れる版を重ねる。

**登場アニメを `t=0` で止めると何も写らない。** `opacity:0` のまま。
有限のものは `finish()`、無限のものだけ `pause()` する。

**`document.hidden` だとCSSアニメーションが止まる。**
`getComputedStyle` も進まないので「動いていない」と誤診する。
`a.pause(); a.currentTime = t;` で時刻を直接動かして読む。

**`transform:scale` の基準は `transform-box:fill-box; transform-origin:center`**（SVG図形）。

---

## 測定

**🚨 `getBoundingClientRect()` はレイアウト確定前だと古い値を返す。**
リサイズ直後・クラス付与直後は待ってから測る。「すき間28px」と誤診した（実際10px）。

**閉じている `<details>` の中身は測れない。** `::details-content` の
`content-visibility:hidden` で配下のレイアウトが飛ぶ。開けてから測る。

**文字入りの画像で背景を測ると前の行のグリフを拾う。**
`.copy{visibility:hidden}` の版を別に描き出す。

**白文字は「一番明るい背景」が最悪ケース。** 黒文字と逆。取り違えると全部OKに見える。

**測定窓が隣の要素を拾う。** 「合っていない」は測定の誤りのことが多い。
**数字が変なときは拡大して目で確かめる。**

**要素を挿入したら `children[n]` のインデックスがずれる。**
`<i>` と `<svg>` を先頭に足したせいで `children[1]` が別物になり、
自分自身と比較して「ズレ0」と誤判定した。クラスで取る。

---

## 撮影・検証

**`mask-image` のアイコンは `file://` では出ない。**
headlessだと空の丸に見える。**実害はない**のでそこで悩まない。

**shot ページの相対パスが解決しない。** `_shot/` から見ると `img/...` が引けない。
`<base href="../">` を差す。

**headless の375px描画は当てにならない。** 溢れて見えても実ブラウザでは正常。
スマホ検証は実ブラウザの `getBoundingClientRect`。

**`100svh` の節は縦長の窓で撮ると下の節が写らない。** 節単位のページを別に作る。

**画像のデコードが撮影に間に合わない。** 空白に見えるだけ。少し待って撮り直す。

**同じURLに `#hash` を付けても再読込されない。** クエリを変える（`?v=2`）。

**ブラウザが古いHTMLをキャッシュする。** 確認は `Cmd+Shift+R`。
クライアントに送るときも一緒に伝える。

---

## スクリプト

**`assert` が落ちると書き込みまで到達しない。** 前段の置換も含めて丸ごと失われる。
**1スクリプト1目的**にするか、全 `assert` を先に通してから書く。

**セレクタ文字列が2箇所に一致する。** `.fstep__arrow{` は
`.fstep__arrow{` と `.fstep__arrow{display:none}` の両方に当たる。
改行を含めて一意にする（`"\n.fstep__arrow{\n"`）。

**Pythonのヒアドキュメントで `</script>` を書くと壊れる。**
JS文字列の中でないなら `<\/script>` とエスケープしない。生で書く。

**正規表現が広く当たる。** `re.sub(r'(</h3>\n          )<p>')` が12箇所を書き換えた。
置換件数を数えて期待値と突き合わせる。

**タグの入れ子を1つ落とす。** 閉じ忘れで親が閉じず、続く要素まで巻き込んで潰れる。
**入れ子を変えたら必ず描き出して確認する。**

**この環境に `timeout` はない**（exit 127）。`pdftoppm` もない → PyMuPDF (`fitz`) を使う。
`ffmpeg` / Homebrew もない。

---

## デプロイ

**GitHub Pages のビルドを待つ。** push 直後は古い版が返る。
`until curl … | grep -q '<新しい文字列>'; do sleep 5; done` で待つ。

**日本語で grep すると環境によって外す。** クラス名や数値で待つ。

**`grep -c` は0件で exit 1。** 待ち合わせの最後に置くとジョブが失敗扱いになる。

**public リポジトリを確認する。** クライアント素材・人物写真を置く前に
`gh repo view --json visibility` と `.gitignore` を見る。
**未追跡は「安全」ではない。** `git add -A` 一発で公開される。
