# 背景と図解

## FVの背景をコードで作る

写真がない／使えないとき、背景はSVGで組む。画像を差し替えても崩れず、色も後から変えられる。

**層の作り**（下から）：

1. `<rect>` に地のグラデ（明→暗）
2. `<radialGradient>` の白いグロー（見出しの周りだけ抜く）
3. 濃色の楔（`<path>` を2〜3枚）
4. 縦線の束・斜線・輪郭図形
5. ドットのパターン
6. 小さな粒（motes）

```css
.hero__bg{
  position:fixed; top:0; left:0; width:100%; height:100svh;
  z-index:0; overflow:hidden; background:#01050e;
}
.hero > *:not(.hero__bg){z-index:2}
section:not(.hero),footer{position:relative; z-index:1}
```

🚨 **`z-index:-1` にすると `html,body` の背景に負ける。** `0` にして、後続の節を `1` に上げる。

### 明→暗の境目が思ったところに来ない

**白いグローが効きすぎているのが原因のことが多い。** 地のグラデをいくら暗くしても、
上に載った白い放射グラデが中央まで届いていると明るいまま。

実測の例：`r=.64` のグローが x1505（表示1295px）まで白を届かせていた。
`r=.47` に絞って初めて地の暗さが出た。

### 境目の位置は実測で決める

```
文字の右端 → フォーム左端 のあいだに濃色の帯が出ているか
```

**背景だけを描き出して**（`.copy{visibility:hidden}`）、行ごとに輝度が128を割るxを測る。

---

## 常時アニメーション

「エフェクトをかける」のではなく**背景の要素そのものを動かす**。

| 動き | やり方 |
| --- | --- |
| 線の上を明るい区間が流れる | `stroke-dasharray` ＋ `stroke-dashoffset` |
| 層がゆっくり漂う | `transform:translate()` を 10〜26s で往復 |
| 節点が呼吸する | `opacity` ＋ `scale`（`transform-box:fill-box`） |
| 輪が広がって消える | `r` と `opacity` を同時に |
| 明滅 | `opacity` を 7〜11s で往復 |

**時間をずらす。** 同じ周期だと機械的に見える。`--t:4.6s / 5.4s / 4.1s` のように
素数っぽくばらし、`animation-delay` を負の値にして初期位相もずらす。

### 🚨 `stroke-dashoffset` の keyframe に `calc(var(--x))` を書くと補間されない

これが「線が流れて見えない」の原因。実測すると値が飛んでいる：

```
修正前  0% → 1150px   25% → 1150px   50% → 0px      75% → 0px       ← 離散
修正後  0% →    0px   25% →    0px   50% → -362.7px  75% → -759.5px  ← 線形
```

`calc()` の中に `var()` があると計算値の時点で解決しきれず、CSSは**離散補間**に落とす。
**線ごとに実数で keyframes を書く。**

```css
.fx-beams .b1{--len:1150; animation:fxDraw 1.5s ease .3s both, fxFlow1 7s linear 1.9s infinite}
@keyframes fxFlow1{
  from{stroke-dasharray:0 0 437 1150; stroke-dashoffset:0}
  to  {stroke-dasharray:0 0 437 1150; stroke-dashoffset:-1587}
}
```

全 `@keyframes` を走査して `calc(var())` が残っていないか確認する：

```python
import re
for m in re.finditer(r'@keyframes\s+([\w-]+)\s*\{', s):
    name=m.group(1); i=m.end(); depth=1; j=i
    while depth and j<len(s):
        if s[j]=='{':depth+=1
        elif s[j]=='}':depth-=1
        j+=1
    if 'calc(' in s[i:j-1] and 'var(' in s[i:j-1]: print('要修正:', name)
```

### 網の形を残したまま光を走らせる

1本の線で dasharray を動かすと**網の形ごと消える**。
**静止版と流れる版を重ねる。**

```html
<g class="bn-lines"> …同じパス3本（細く・薄く）… </g>
<g class="bn-pulse"> …同じパス3本（太く・明るく・流れる）… </g>
```

濃色の地では `#c3c8d1` は沈む。`.is-dark` で白のアルファに差し替える。

### 検証

`prefers-reduced-motion` で止める。無限アニメの本数は
`getAnimations({subtree:true}).filter(a=>a.playState==='running').length` で数える。

---

## 図解

### 連結線は「端点になる要素」を基準にする

🚨 **パスに実測値を焼き込むと、周りの余白を1回変えただけで壊れる。**

```html
<!-- ✕ 実測値を焼き込んでいる -->
<svg viewBox="0 0 100 100" preserveAspectRatio="none">
  <path d="M27 0 L40 42.4"/>
</svg>
```

`.bars{padding-right}` を 146px → 32px に詰めた瞬間、27%/40% が別の場所を指した。

**直し方：線が占める矩形を、端点の要素そのものから作る。**

```css
.bars{
  --bgap:clamp(20px,2.6vw,38px);
  --ha:clamp(84px,11.7vw,169px);   /* 高い棒 */
  --hb:clamp(48px,6.7vw,97px);     /* 低い棒 */
  gap:var(--bgap);
}
.bar--a{height:var(--ha)}  .bar--b{height:var(--hb)}

/* 高い棒の右上角から低い棒の左上角まで、ちょうどその矩形を占める。
   中身は左上→右下の対角1本だけなので、幅も間隔も勝手に合う */
.bar__link{position:absolute; left:100%; top:0;
  width:var(--bgap); height:calc(var(--ha) - var(--hb))}
```
```html
<svg class="bar__link" viewBox="0 0 100 100" preserveAspectRatio="none">
  <path d="M0 0 L100 100"/>
</svg>
```

実測：端点と棒の角のズレが 1440 / 1024 / 375 すべて **0px**。

### 列の中心を計算で出す

`repeat(N,1fr)` ＋ `gap` のグリッドなら、列幅と中心は計算できる。

```css
.fturn{
  --fcol:calc((100% - var(--fgap) * 2) / 3);   /* 3列の1列ぶん */
  --fc1:calc(var(--fcol) / 2);                 /* 1列目の中心 */
  --fc3:calc(100% - var(--fcol) / 2);          /* 3列目の中心 */
}
```

### 折り返しの線が途切れる

親と次の行のあいだにマージンがあると、そのぶん線が届かない。
**同じ値を変数に出して、マージンと線の伸ばし量を1箇所から出す。**

```css
.flow{--fturn-gap:clamp(6px,.7vw,10px)}
.fturn + .flow__row{margin-top:var(--fturn-gap)}
.fturn__mid{top:calc(-1 * var(--fturn-gap))}   /* 同じ変数ぶん上へ伸ばす */
```

継ぎ目は**すべて実測する**。0 か負（重なり）ならOK。

### grid の1行は高さが揃う ＝ 中央が計算不要

`display:grid` の1行なら、コンテナの高さ＝一番高いアイテムの高さ。
つまり**コンテナの `top:50%` がそのままアイテムの上下中央**になる。
箱の高さは文の折り返しで決まるので clamp では当てられない。この性質を使う。

### 対比図は「1つの入口 → 2つの行き先」

「一般的な構成 vs 自社の構成」を見せるなら、**流れを2本描く**。
片方だけ描いて、もう片方を ✕ 付きの終点として置くのは**対比になっていない**。

```
        ┌──────── 診断対象 ────────┐
        └────────────┬───────────┘
              ┌──────┴──────┐
              ↓              ↓
      ┌ 一般的な構成 ┐   ┌ 自社の構成 ┐
```

🚨 **✕ の位置に注意。** 「一般的な構成」は*実際に送信されている*流れなので、
そこに ✕ を付けると「送信しない」の意味になって逆になる。

### 左右に並べるより上から下

「入口が横にある」と**両方に繋がっていることが読み取れない**。
入口を上に置いて、そこから下へ分岐させる。
