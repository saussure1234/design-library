# 日本語LPのレスポンシブ

## FVの背景が「入っていない」

いちばん多い症状。原因は**背景がコンテンツの後ろに敷かれていない**こと。
PC用に `position:fixed` で組んだ背景を、スマホで `position:relative` に落とすと
**背景ではなく独立したバナー**になり、コピーはその下の無地の上に乗る。

```css
@media (max-width:900px){
  .hero{position:relative; overflow:hidden; display:block; background:transparent;
        min-height:calc(100svh - var(--head-h) - 96px)}
  .hero__bg{position:absolute; inset:0; width:100%; height:100%; aspect-ratio:auto; z-index:0}
  .copy{position:relative; z-index:2}
}
```

スマホは `fixed` にしない。URLバーの伸縮で背景が跳ねる。

## 🚨 暗い絵に白いベールを重ねると「グレー」になる

暗い絵 × 白のベール ＝ 中間のグレー。**沈んで見える最大の原因。**

**濃色側に振り切る。** 絵はそのまま見せ、文字とアイコンを白にする。
白いフォームの箱が浮いてコントラストが立つ。

```css
@media (max-width:900px){
  .hero::before{
    content:""; position:absolute; inset:0; z-index:1; pointer-events:none;
    background:
      linear-gradient(180deg, rgba(3,10,24,.34) 0%, rgba(3,10,24,.56) 44%, rgba(3,10,24,.74) 100%),
      linear-gradient(90deg,  rgba(3,10,24,.34) 0%, rgba(3,10,24,.12) 70%, rgba(3,10,24,0) 100%);
  }
  .h1{color:#fff}
  .lead{color:rgba(255,255,255,.88)}
  .pillar h3{color:#fff}
  .pillar__ico--m{background:#fff}   /* mask のアイコンは background で色が変わる */
}
```

**白文字のときは一番「明るい」背景が最悪ケース**（黒文字と逆）。取り違えると全部OKに見える。

## 横長の絵を縦長の画面に入れる

`preserveAspectRatio="…slice"` だと、縦長の画面には**縦に細い短冊**しか映らない。

**絵のどこを映すかを幅で切り替える。** ただし `viewBox` も `preserveAspectRatio` も
CSSでは切り替えられないので JS。`<svg>` 直後の同期スクリプトなら描画前に走ってチラつかない。

```js
var wins = [
  { mq: matchMedia('(max-width:600px)'), vb: '1010 0 520 941' },
  { mq: matchMedia('(max-width:900px)'), vb: '860 0 812 941'  }
];
var cur='';
function set(){
  var vb='0 0 1672 941';
  for (var i=0;i<wins.length;i++) if (wins[i].mq.matches){ vb=wins[i].vb; break; }
  if (vb===cur) return;            // iOSのアドレスバー伸縮で毎回書かない
  cur=vb; el.setAttribute('viewBox', vb);
}
set();
wins.forEach(w => w.mq.addEventListener('change', set));
addEventListener('resize', set, {passive:true});      // change が飛ばない環境の保険
addEventListener('orientationchange', set);
```

🚨 **どこを映すかは、絵を実際に描き出して目で決める。**
一度「右端を残す」設定にしたが、書き出したら**右端はほぼ無地**で、
背景が消えて見える原因そのものだった。

🚨 **`preserveAspectRatio` を全幅で `xMax` にするとPCの絵がズレる**（1440pxで約80px）。幅で切り替える。

---

## 比較表：縦積みにしない

2列の比較表をスマホで1列に積むと、**「A社を5行ぜんぶ読んでからB社を5行読む」**形になり、
行ごとの比較ができない。**3列のまま横スクロールさせる。**

```html
<div class="cmp-scroll">
  <div class="cmp-t"> …項目 / A社 / 自社… </div>
</div>
```
```css
@media (max-width:900px){
  .cmp-scroll{
    overflow-x:auto; -webkit-overflow-scrolling:touch;
    margin-inline:calc(-1 * clamp(24px,6vw,110px));   /* .wrap の左右パディングを打ち消す */
    padding-inline:clamp(24px,6vw,110px);             /* 同量を戻す */
  }
  .cmp-t{grid-template-columns:124px 164px 164px; min-width:452px; gap:0}
  .cmp-t__col--item{position:sticky; left:0; z-index:2; background:#fff}  /* 項目名を残す */
  .cmp-t__label{display:none !important}   /* セル内に出していた項目名は不要になる */
}
```

要点：

- **1列目を sticky にする。** 横に送っても「何の項目か」が消えない
- **右端で最後の列が少し切れる** ＝ スクロールできる合図になる
- 自社列を先に置けるなら、DOM順を `項目 → 自社 → 他社` にすると自社が全部見える
- 項目名の列は**124px以上**取る。84pxだと「レポ／ート」「見積算出方／法」と割れた
- 負のマージンは横溢れを起こしやすい。`padding-inline` で同量戻し、
  `document.scrollWidth == clientWidth` を必ず実測する

`display:contents` の行を使っている表は、スマホで `display:block` に変えていることが多い。
横スクロールに戻すなら `display:contents` に戻す。

---

## 積む順番を変える

DOM順が「画像 → テキスト」だと、スマホで**見出しに辿り着く前に大きな画像**が来る。
DOMは触らず `order` で入れ替える。

```css
@media (max-width:900px){
  .book{display:flex; flex-direction:column}
  .book .wrap{order:1}      /* テキストを先に */
  .book__visual{order:2}    /* 画像は後ろへ */
}
```

`::before` / `::after` は絶対配置なら flex アイテムにならないので巻き込まれない。

---

## 人物の切り抜きは「上」に出す

**下にはみ出させると切り抜きの断面が見える。** バストアップの切り抜きは
胸のところで真横一直線に切れているので、枠の下から出すと平らな断面が地の上に載って
「シール」に見える。

立体感が出るのは**頭が枠の上を越える**方。胸の切り口は枠の下端にぴったり合わせて隠す。

```css
.exp__photo{overflow:visible}     /* 人物だけ枠の外へ */
.exp__net{clip-path:inset(0)}     /* 背景の絵は枠内に切る */
.exp__photo img{height:106%; max-width:70%}
```

🚨 **`max-width` が先に効くと `object-fit:contain` が高さを縮めて枠内に収まる。**
`height:116%` にしても頭が出ないのはこれ。上限を緩めて高さ側を効かせる。

実測：頭のはみ出し 10〜16px、胸の切り口と枠下端の差 **0px**（全幅）。

---

## `<details>` を滑らかに開く

素の `<details>` は一瞬で開く。**中の要素を animate しても効かない**——
閉じている間 Chrome は `::details-content` に `content-visibility:hidden` を当てていて、
その配下はレイアウトごと飛ばされる。**`<details>` 自身の高さ**を送る。

```js
var from = h();                       // cancel 前に今の高さを取る（途中から反転できる）
if (anim) { anim.cancel(); anim = null; }
d.open = true;  var to = h();         // 開いた後の自然高
anim = d.animate([{height:from},{height:to}], {duration:300, easing:'cubic-bezier(.22,.68,.3,1)'});
```

閉じるときは `d.open=false; to=h(); d.open=true;` で**閉じた高さだけ借りて**、
アニメ終了後に本当に閉じる。

罠2つ：

| | |
| --- | --- |
| アイコンが遅れて＋に戻る | `open` が外れるのはアニメ終了後。`is-closing` を先に付け、`[open]:not(.is-closing)` で判定 |
| 連打すると2回続けて閉じる | 閉じアニメ中は `open` がまだ true。`closing \|\| !d.open` で「開く」を判定 |

---

## タップ領域

チェックボックス本体は18px程度でよいが、**行ごと44px**にする。

```css
.hform__agree{min-height:44px; display:flex; align-items:center}
```

本文中のリンク（プライバシーポリシー等）は行内なので16〜17pxになる。これは仕様。

---

## アンカーと sticky ヘッダー

アンカーの着地がヘッダーに潜らないこと。`html{scroll-padding-top}` か
対象の `scroll-margin-top` で、ヘッダー高＋数pxの余裕を取る。

🚨 **ペインを隠した状態だと `scroll-behavior:smooth` が走らず `scrollY:0` に見える。**
検証はタブを前面にしてから。

---

## 毎回測る5つ

| 項目 | 基準 |
| --- | --- |
| 横溢れ | `document.scrollWidth == clientWidth`（375 / 768 / 1440） |
| 文字切れ | `scrollWidth > clientWidth + 2` の要素が0 |
| 小さすぎる字 | 本文12px未満が0（図中も含む） |
| コントラスト | 本文4.5:1、大見出し3:1 |
| タップ領域 | 44px |

`scripts/audit.js` を貼れば全部出る。
