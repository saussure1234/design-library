#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ITEMS.md を checklist.json / rules.json / check.py から作り直す。

  python3 gen_items.py            # ITEMS.md を書き出す
  python3 gen_items.py --stdout   # 画面に出すだけ

★なぜ生成にするか
  項目の実体は checklist.json（見る観点）と check.py（判定コード）で、
  一覧を手で書くと必ず片方だけ直されてズレる。ズレた一覧は「見たつもり」を作る。
  項目を増やす・変えるときは JSON とコードを直して、これを回す。
"""
import io
import json
import os
import re
import sys

R = os.path.expanduser("~/design-library")
HERE = os.path.dirname(os.path.abspath(__file__))
WHO = {"machine": "機械", "claude": "Claude", "human": "人"}


def load_check():
    """check.py から、どう直すか（HOW）・マーカーの並び・判定の行番号を取る。"""
    src = io.open(os.path.join(R, "check.py"), encoding="utf-8").read()
    lines = src.splitlines()

    how = {}
    m = re.search(r"^HOW = \{(.*?)^\}", src, re.S | re.M)
    if m:
        for k, v in re.findall(r'"([a-z0-9-]+)":\s*((?:"[^"]*"\s*\n?\s*)+)', m.group(1)):
            how[k] = re.sub(r'"\s*\n?\s*"', "", v.strip()).strip('"')

    # マーカーの並び（probe の FLAGS と Python の order は同じ順でなければならない）
    order = []
    m = re.search(r'order = \[(.*?)\]', src, re.S)
    if m:
        order = re.findall(r'"([a-z0-9-]+)"', m.group(1))

    # 検出文の頭の言葉 → 項目（MARK）
    mark = {}
    m = re.search(r"MARK = \{(.*?)^\s*\}", src, re.S | re.M)
    if m:
        for k, v in re.findall(r'"([a-z0-9-]+)":\s*\(([^)]*)\)', m.group(1)):
            mark[k] = [x.strip('"') for x in re.findall(r'"([^"]+)"', v)]

    # 判定コードの行番号
    # 🚨 行単位で探すと当たらない。push の引数は複数行にまたがるので、
    #    全文の文字位置で探して行番号に直す（最初は embed-controls 1件しか拾えなかった）。
    # 🚨 「その語より前の直近の push」で探すとコメントを拾う（orphan-line が
    #    別の push を指した）。push の文字列リテラルの中にある場合だけ当てる。
    where = {}
    for k, keys in mark.items():
        for x in keys:
            m2 = re.search(r'push\("[^"]*' + re.escape(x), src)
            if m2:
                where[k] = src.count("\n", 0, m2.start()) + 1
                break
    # 決めごとの判定も同じやり方で拾う
    rwhere = {}
    for m2 in re.finditer(r'rule\("([a-z0-9-]+)"', src):
        rwhere[m2.group(1)] = src.count("\n", 0, m2.start()) + 1
    for m2 in re.finditer(r'src_judge\["([a-z0-9-]+)"\]', src):
        rwhere.setdefault(m2.group(1), src.count("\n", 0, m2.start()) + 1)
    return how, order, mark, where, rwhere


def main():
    cl = json.load(io.open(os.path.join(R, "checklist.json"), encoding="utf-8"))
    items = cl["items"] if isinstance(cl, dict) else cl
    rules = json.load(io.open(os.path.join(R, "rules.json"), encoding="utf-8"))
    how, order, mark, where, rwhere = load_check()

    o = []
    o.append("# チェック項目の一覧（生成物。手で書き換えない）\n")
    o.append("`python3 gen_items.py` で作り直す。実体は次の3つ。\n")
    o.append("| 実体 | 何が入っているか |")
    o.append("| --- | --- |")
    o.append("| `~/design-library/checklist.json` | 見る観点（id・名前・誰が見るか・止めるか・出どころ） |")
    o.append("| `~/design-library/rules.json` | 我々の決めごと（壊れているかではなく、決めたとおりか） |")
    o.append("| `~/design-library/check.py` | 判定のコード（ページの中で動く probe と、幅をまたぐ突き合わせ） |")
    o.append("")
    n = {"machine": 0, "claude": 0, "human": 0}
    for i in items:
        n[i.get("by", "machine")] = n.get(i.get("by", "machine"), 0) + 1
    o.append(f"品質チェック **{len(items)}項目**"
             f"（機械 {n['machine']} / Claude {n['claude']} / 人 {n['human']}）"
             f"＋ 決めごと **{len(rules['rules'])}件**。\n")

    g = {}
    for i in items:
        g.setdefault(i.get("group", "その他"), []).append(i)
    for grp, lst in g.items():
        o.append(f"\n## {grp}（{len(lst)}）\n")
        for i in lst:
            b = "止める" if i.get("blocking", True) else "止めない"
            o.append(f"### {i['name']}　`{i['id']}`")
            o.append("")
            o.append(f"- 誰が: **{WHO.get(i.get('by'), '?')}**　／　落ちたとき: **{b}**")
            o.append(f"- 何を見るか: {i.get('what', '（未記入）')}")
            if how.get(i["id"]):
                o.append(f"- どう直すか: {how[i['id']]}")
            if i["id"] in where:
                o.append(f"- 判定の在り処: `check.py:{where[i['id']]}`"
                         + (f"　／　マーカー {order.index(i['id'])}番目"
                            if i["id"] in order else ""))
            elif i.get("by") == "machine":
                o.append("- 判定の在り処: probe の外（Python 側の台帳・原稿の突き合わせ）")
            fr = i.get("from")
            if isinstance(fr, list):
                fr = "／".join(str(x) for x in fr)
            if fr:
                o.append(f"- 出どころ: {fr}")
            o.append("")

    o.append("\n## 我々の決めごと（別の層）\n")
    o.append("品質チェックでは1件も防げない「こうしてほしい」の指示。"
             "台帳のFB52件を分けたら半分が仕様の指示で、しかも案件をまたいで繰り返し来た。"
             "一度言われたら決めごとにして、次からは機械が見る。**欠陥ではないのでリンクは止めない。**\n")
    for r in rules["rules"]:
        o.append(f"### {r['name']}　`{r['id']}`")
        o.append("")
        o.append(f"- 何を見るか: {r['what']}")
        o.append(f"- なぜ: {r['why']}")
        o.append(f"- 対象: {r.get('scope', '—')}")
        if rwhere.get(r["id"]):
            o.append(f"- 判定の在り処: `check.py:{rwhere[r['id']]}`")
        o.append("")

    o.append("\n## マーカーの並び（変えるときは3箇所を同時に直す）\n")
    o.append("probe は画面の左上に16pxの色マーカーを並べ、撮影した画像から読む。"
             "並び・本数・読み取り数が食い違うと、**赤いはずの項目が緑に見える。**\n")
    o.append("| # | 項目 |")
    o.append("| --- | --- |")
    for k, x in enumerate(order):
        o.append(f"| {k} | `{x}` |")
    o.append("")
    o.append(f"1. probe の `FLAGS` 配列（{len(order)}本）")
    o.append(f"2. `read_flags()` の `range({len(order)})`")
    o.append(f"3. Python の `order` リスト（{len(order)}件）")
    o.append("")

    txt = "\n".join(o) + "\n"
    if "--stdout" in sys.argv:
        print(txt)
    else:
        p = os.path.join(HERE, "ITEMS.md")
        io.open(p, "w", encoding="utf-8").write(txt)
        print(f"  ○ {p}  {len(items)}項目 + 決めごと{len(rules['rules'])}件  {len(txt)//1024}KB")


if __name__ == "__main__":
    main()
