---
name: lp-version
description: LPのリンクを作る・記録する・FBを残す・同じリンクのまま直す。「LPをデプロイして」「別リンクで見せて」「FBが来た」「これを直して」と言われたら必ず使う。フォルダを cp -r で作ってはいけない。派生元を記録せずにリンクを渡すと、どこから来た版か分からなくなる（2026-09-07に事故）。
user-invocable: true
---

# LPのリンクを管理する

**前提：リンクを作る＝クライアントに見せる、ということ。**

だから作りかけをリンクにしない。そして **小さい直しでリンクを増やさない**。
増やすと、クライアントは「どれを見ればいいのか」が分からなくなる。

```bash
python3 ~/design-library/lpv.py ls          # まずこれ。いま何本出ているか
```

管理画面： https://saussure1234.github.io/design-library/lp/ （noindex）

---

## 判断はこの2つだけ

| 何をする | コマンド | リンク |
| --- | --- | --- |
| **小さい直し** | `lpv.py update <id> --what "..."` | **増やさない**（同じリンクの中身を直す） |
| **別案として並べて見せる** | `lpv.py new <新id> ... --alt` | 増やす（CTAの色違いを2本、など） |

`new` は `--alt` を付けないと止まる。止まったら、それは本当に別案かを考える。

---

## 事故の記録（これを防ぐための仕組み）

| いつ | 何が起きたか |
| --- | --- |
| 2026-08-31 | 派生元を記録せずに枝を伸ばし、どのリンクが最新か分からなくなった |
| 2026-09-06 | git の外（Desktopの複製）で633行直した。正が2つになった |
| 2026-09-07 | クライアントから「FB反映前の版が上がっている」と注意された。1日で確認用リンクが5本並び、古いものを見続けられていた |

---

## 手順

### ① 作業を始める前

```bash
python3 ~/design-library/lpv.py ls <案件id>
```

**いまクライアントに渡っているリンクがどれかを確認する。**

### ② FBが来たら【直す前に】記録する

```bash
python3 ~/design-library/lpv.py fb esl11 --what "CTAが地の緑と同色で埋もれている"
```

直してから書こうとすると、直した内容しか残らず「何を言われたか」が消える。

### ③ 小さい直し ─ リンクは増やさない

```bash
python3 ~/design-library/lpv.py update esl11 --what "価格の色をもう一段濃く"
```

`docs/<id>/` の中身を直して、これを打つ。リンクは同じまま、更新履歴だけ積む。

### ④ 別案として並べて見せる時だけ、新しいリンク

```bash
python3 ~/design-library/lpv.py new esl12 -p eslclub-online \
    --from esl11 --alt --why "CTAをオレンジにした案"
```

- `--from` は省略できない（初版だけ `--root`）
- `--alt` が無いと止まる。**止まったら勝手に付けない。** 小さい直しなら `update`
- `--src` を省くと `--from` のフォルダを複製する
- design-library の外に出す案件は `--url https://...`

### ⑤ 公開する

```bash
python3 ~/design-library/lpv.py build --push
```

台帳を検査してから生成する。エラーがあれば生成せずに止まる。
`--push` は commit と push をするので、**実行前に必ずユーザーに確認する。**

---

## やってはいけないこと

| だめ | 代わりに |
| --- | --- |
| `cp -r docs/esl6 docs/esl7` | `lpv.py new esl7 -p ... --from esl6 --alt --why "..."` |
| 小さい直しのたびに新しいリンク | `lpv.py update`（同じリンクのまま） |
| 止まった時に `--alt` を自己判断で付ける | ユーザーに聞く。本当に並べて見せるのか |
| `lp-registry.json` を手で編集 | `lpv.py` の各コマンド |
| Desktop の複製フォルダで作業 | `~/design-library/docs/<id>/` で直接 |

---

## 案件を新しく立てる

```bash
python3 ~/design-library/lpv.py new-project <案件id> \
    --name "<案件名>" --client "<クライアント名>"
python3 ~/design-library/lpv.py new <id> -p <案件id> \
    --root --why "初版" --src ~/Desktop/<作業フォルダ>
```

**このリポジトリは公開。** 金額を書かない。
`.publish-blocklist`（git管理外）に載せた語を含むファイルは公開されない。

---

## 台帳の項目

`~/design-library/lp-registry.json`

| | |
| --- | --- |
| `parent` | 派生元。**これが命**。どのリンクをコピーして始めたか |
| `status` | live=公開（リンクがある）/ draft=未公開（リンクなし） |
| `updates` | 同じリンクのまま直した履歴 |
| `url` | design-library の外に出す時だけ書く |
| `alert` | 気をつける事。管理画面の上に赤く出る |
| `fb` | いつ何を言われたか |

`lpv.py check` が検査するもの：idの重複・存在しない派生元・**派生元の循環**・
statusの誤り・日付の形式・公開先のファイルが無い。

不要になったら `lpv.py rm <id>` / `lpv.py rm-project <案件id>`。
**どちらも台帳から外すだけで `docs/` のファイルは消さない**（渡した相手がまだ開くため）。

---

## フロー全体のどこにいるか

LP案件フローの **13・14・15工程目**（リンクを作って見せる → FBを受ける → 直す）。

| 工程 | 担当 |
| --- | --- |
| 0〜7 提案（リサーチ→精読→強み→時間軸→スライド→構成案→確認事項） | `lp-proposal` |
| 8〜12 制作（テンプレ選定→デザイン案→コード化→仕上げ→検証） | `lp-repro` / `lp-polish` |
| 13〜15 公開・管理 | **これ** |

フローの全体像は管理画面の「LP制作フローとスキル」。定義は `~/design-library/lp-flow.json`。
