---
name: lp-version
description: LPの版を作る・公開する・FBを記録する・本線に取り込む。「LPをデプロイして」「◯◯にして別リンクで」「esl12を作って」「FBが来た」「これを本線にして」と言われたら必ず使う。版のフォルダを cp -r で作ってはいけない。派生元を記録せずにリンクを渡すと、施主が古い版を見続ける事故になる（2026-09-07に発生）。
user-invocable: true
---

# LPの版を管理する

**やること：新しいリンクを作る操作は `lpv.py new` だけにする。**

`cp -r docs/esl6 docs/esl7` を打った瞬間に、その版がどこから来たかは永久に失われる。
台帳は人が思い出して書くものではなく、版を作る操作の副産物にする。

```bash
python3 ~/design-library/lpv.py ls          # まずこれ。いまの本線を確認する
```

管理画面： https://saussure1234.github.io/design-library/lp/ （noindex）

---

## 事故の記録（これを防ぐための仕組み）

| いつ | 何が起きたか |
| --- | --- |
| 2026-08-31 | 本線 esl2 ではなく実験用の esl3 の上に esl6 を積んだ。誰も乗り換えを決めていないのに実験の枝が作業線になり、本線は8/17で止まった |
| 2026-09-06 | git の外（Desktopの複製）で633行直した。正が2つになった |
| 2026-09-07 | 施主から「FB反映前の版が上がっている」と注意された。見ていたのは止まったままの esl2 |

**根本原因は「完了」の定義。** 確認用リンクが出来た時点で完了にしていた。
完了は **本線に取り込まれた状態**（`merged: true`）。

---

## 手順

### ① 作業を始める前

```bash
python3 ~/design-library/lpv.py ls <案件id>
```

**本線がどれかを声に出して確認する。** 派生元は原則そこ。

### ② FBが来たら【直す前に】記録する

```bash
python3 ~/design-library/lpv.py fb esl11 --who 施主 --what "CTAが地の緑と同色で埋もれている"
```

直してから書こうとすると、直した内容しか残らず「何を言われたか」が消える。

### ③ 新しい版を作る

```bash
python3 ~/design-library/lpv.py new <新版id> -p <案件id> \
    --from esl11 --why "CTAをオレンジに"
```

- `--from` は省略できない（初版だけ `--root`）
- `--src` を省くと `--from` の版のフォルダを複製する
- **本線以外から派生させようとすると止まる。** 止まったら勝手に `--branch` を付けない。
  ユーザーに「本線 X から外れて Y の枝を伸ばすが良いか」を聞く
- design-library の外に出す案件は `--url https://...` を付ける（ファイルは複製しない）

### ④ 公開する

```bash
python3 ~/design-library/lpv.py build --push
```

台帳を検査してから生成する。エラーがあれば生成せずに止まる。
`--push` は commit と push をするので、**実行前に必ずユーザーに確認する。**

### ⑤ 採用が決まったら本線に取り込む

```bash
python3 ~/design-library/lpv.py merge esl12
```

ここまでやって完了。本線が入れ替わり、旧本線は凍結になる。

---

## やってはいけないこと

| だめ | 代わりに |
| --- | --- |
| `cp -r docs/esl6 docs/esl7` | `lpv.py new esl7 -p ... --from esl6 --why "..."` |
| `lp-registry.json` を手で編集 | `lpv.py` の各コマンド |
| Desktop の複製フォルダで作業 | `~/design-library/docs/<版id>/` で直接 |
| 止まった時に `--branch` を自己判断で付ける | ユーザーに聞く。ここが 8/31 の分岐点 |
| 確認用リンクを渡して「完了」と言う | `merge` するまで「本線未反映」と言う |

---

## 案件を新しく立てる

```bash
python3 ~/design-library/lpv.py new-project <案件id> \
    --name "<案件名>" --client "<クライアント名>"
python3 ~/design-library/lpv.py new <版id> -p <案件id> \
    --root --status live --why "初版" --src ~/Desktop/<作業フォルダ>
```

**このリポジトリは公開。** 台帳・フロー定義に顧客名や金額を書かない。
`.publish-blocklist`（git管理外）に載せた語を含むファイルは公開されない。

---

## 台帳の項目

`~/design-library/lp-registry.json`

| | |
| --- | --- |
| `parent` | 派生元の版id。**これが命** |
| `merged` | 本線に取り込まれたか。完了の定義 |
| `status` | live 本番 / frozen 凍結 / review 確認用 / draft 未公開 |
| `url` | design-library の外に出す時だけ書く |
| `alert` | 気をつける事。管理画面の上に赤く出る |
| `fb` | いつ誰に何を言われたか |

`lpv.py check` が検査するもの：版idの重複・存在しない派生元・**派生元の循環**・
本線の未設定・statusの誤り・公開先のファイルが無い・live なのに未反映。

---

## フロー全体のどこにいるか

LP案件フローの **13・14・15工程目**（初稿を版として公開 → 提示してFB → 本線に取り込む）。

| 工程 | 担当 |
| --- | --- |
| 0〜7 提案（リサーチ→精読→強み→時間軸→スライド→構成案→確認事項） | `lp-proposal` |
| 8〜12 制作（テンプレ選定→デザイン案→コード化→仕上げ→検証） | `lp-repro` / `lp-polish` |
| 13〜15 公開・管理 | **これ** |

フローの全体像は管理画面の「LP制作フローとスキル」。定義は `~/design-library/lp-flow.json`。
